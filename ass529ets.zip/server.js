const express = require("express")
const cors = require("cors")

const app = express()
app.use(cors())
app.use(express.json())

// تسجيل دخول تجريبي
app.post("/login", (req, res) => {
    const { username, password } = req.body

    if (username === "admin" && password === "1234") {
        return res.json({
            success: true,
            token: "ABC123TOKEN"
        })
    }

    res.status(401).json({ success: false })
})

// اختبار السيرفر
app.get("/", (req, res) => {
    res.send("Server is running ✅")
})

const PORT = process.env.PORT || 3000
app.listen(PORT, () => console.log("Running on", PORT))